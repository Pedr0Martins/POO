#include <iostream>
using namespace std;


void imprime(const string &frase){
    cout << frase << endl;
}

void imprime(const string &frase, int i){
    cout << frase << " + " << i << endl;
}

void imprime(int i, const string &frase){
    cout << i << " + " << frase << endl;
}


int main(){

    imprime("programacao orientada a objetos");

    imprime("horas por aula teorica ", 2);

    imprime(3, " horas em cada aula pratica");

    return 0;

}
