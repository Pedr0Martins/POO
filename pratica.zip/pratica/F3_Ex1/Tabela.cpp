#include "Tabela.h"

TabelaNumeros::TabelaNumeros(const int& valor) {
    preencherValor(valor);
}

TabelaNumeros::TabelaNumeros(const int& valorInicial, const int& incremento) {
    int aux = valorInicial;
    for (int i = 0; i < TAM; i++) {
        this->numeros[i] = aux;
        aux += incremento;
    }
}

TabelaNumeros::TabelaNumeros(const std::initializer_list<int>& lista) {
    int i = 0;
    for (const int& numero : lista) {
        if (i < TAM) {
            this->numeros[i++] = numero;
        }
    }

    if (i < TAM) {
        for (; i < TAM; i++) {
            this->numeros[i] = 0;
        }
    }
}

void TabelaNumeros::preencherValor(const int& numeros) {
    for (int i = 0; i < TAM; i++) {
        this->numeros[i] = numeros;
    }
}

int& TabelaNumeros::ElementoEm(const int& posicao) {
    if (posicao > 0 && posicao <= TAM) {
        return this->numeros[posicao - 1]; // Subtrai 1 para corresponder ao índice C++
    }

    static int lixo = 0;
    return lixo;
}

void TabelaNumeros::ListarElementos() const {
    for (const int& numero : numeros) {
        std::cout << numero << " ";
    }
    std::cout << std::endl;
}

std::span<int> TabelaNumeros::DevolverValoresNaMatriz() {
    return std::span<int>(numeros);
}

bool TabelaNumeros::ExisteNum(const int& numero) {
    for (const int& num : numeros) {
        if (num == numero) {
            return true;
        }
    }
    return false;
}

bool TabelaNumeros::VerificaElementosIguais(span<int> lista) {

    if (lista.size() != TAM) {
        return false;
    }

    for (int i = 0; i < TAM; i++) {
        if (lista[i] != numeros[i]) {
            return false;
        }
    }

    return true;
}

TabelaNumeros::~TabelaNumeros() {
    cout << "Destrutor chamado. Destruido" << endl;
}

TabelaNumeros TabelaNumeros::Recebe(const TabelaNumeros &tabela) {
    cout << "Recebe chamado. Construido por copia" << endl;

}

TabelaNumeros TabelaNumeros::Inicializa(const TabelaNumeros &tabela) {
    cout << "Inicializa chamado. Construido por atribuicao" << endl;
}



