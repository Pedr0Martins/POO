
#ifndef F3_EX1_TABELA_H
#define F3_EX1_TABELA_H

#include <iostream>
#include <vector>
#include <span>
#include <initializer_list>

const static int TAM = 10;
using namespace std;

class TabelaNumeros {
public:
    TabelaNumeros(const int& valor = 0);
    TabelaNumeros(const int& valorInicial, const int& incremento);
    TabelaNumeros(const std::initializer_list<int>& lista);

    void preencherValor(const int& numeros);
    int& ElementoEm(const int& posicao);
    void ListarElementos() const;
    span<int> DevolverValoresNaMatriz();
    bool ExisteNum(const int& numero);
    bool VerificaElementosIguais(std::span<int> lista);

    ~TabelaNumeros();
    static TabelaNumeros Recebe(const TabelaNumeros& tabela);
    static TabelaNumeros Inicializa(const TabelaNumeros& tabela);


private:
    const static int TAM = 10;
    int numeros[TAM];
};

#endif //F3_EX1_TABELA_H