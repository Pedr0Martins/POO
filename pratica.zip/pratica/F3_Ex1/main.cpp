#include "Tabela.h"

int main() {

    TabelaNumeros tabela(10, 20);

    /*TabelaNumeros tabela2{20};
    TabelaNumeros tabela3 = {30};
    TabelaNumeros tabela4 = TabelaNumeros(40);
    TabelaNumeros tabela5 = (50);*/


    for(int& numero : tabela.DevolverValoresNaMatriz()){
        cout << numero << " ";
    }
    cout << endl;

    cout << tabela.DevolverValoresNaMatriz().size() << endl;


    tabela.Recebe(tabela);
    tabela.Inicializa(tabela);
    tabela.~TabelaNumeros();

    return 0;
}
