#include "Apartamento.h"

Apartamento::Apartamento(int area) : Imovel(area), andar(andar) {}

string Apartamento::obtemCodigo() {
    return "Apartamento";
}

string Apartamento::obtemDescricao() {
    stringstream oss;
    oss << Imovel::obtemDescricao() << endl;
    return oss.str();

}


