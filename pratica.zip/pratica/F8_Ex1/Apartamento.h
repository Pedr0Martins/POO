#ifndef F8_EX1_APARTAMENTO_H
#define F8_EX1_APARTAMENTO_H

#include "Imovel.h"

class Apartamento: public Imovel{
public:
    Apartamento(int area);

    string obtemCodigo() override;

    string obtemDescricao() override;

private:
    int andar;
};


#endif //F8_EX1_APARTAMENTO_H
