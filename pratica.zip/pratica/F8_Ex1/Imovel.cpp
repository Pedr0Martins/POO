#include "Imovel.h"

string Imovel::obtemDescricao() {
    stringstream oss;
    oss << "Imovel: " << obtemCodigo() << endl;
    oss << "Area: " << obtemArea() << endl;
    oss << "Preco: " << obtemPreco() << endl;
    oss << "Andar: " << obtemAndar() << endl;
    return oss.str();


}
