#ifndef F8_EX1_IMOVEL_H
#define F8_EX1_IMOVEL_H

#include <string>
#include <vector>
#include <iostream>
#include <sstream>
using namespace std;



class Imovel {
public:
    Imovel(int area);

    virtual string obtemCodigo() = 0;

    virtual int obtemPreco() = 0;

    virtual int obtemAndar() = 0;

    int obtemArea();

    virtual string obtemDescricao();
private:
    int area;

};


#endif //F8_EX1_IMOVEL_H
