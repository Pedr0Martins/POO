#ifndef F4_EX1_TRIANGULO_H
#define F4_EX1_TRIANGULO_H
#include "Ponto.h"

class Triangulo {
    public:
    Triangulo(const string& nome, const Ponto& p1, const Ponto& p2, const Ponto& p3);
    ~Triangulo();

    Ponto getVertice(int num) const;
    void setVertice(int num, const Ponto& novoPonto);

    string getNome() const;
    void setNome(const string& novoNome);

    string getDataT() const;


private:
    Ponto vertices[3] = {Ponto(0,0), Ponto(0,0), Ponto(0,0)};
    string nome;
};








#endif //F4_EX1_TRIANGULO_H
