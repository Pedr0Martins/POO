#ifndef F4_EX1_PONTO_H
#define F4_EX1_PONTO_H

#include <iostream>
#include <string>
#include <cmath>

using namespace std;


class Ponto {
public:
    Ponto(float x, float y);
    ~Ponto();

    float getX() const;
    float getY() const;

    void ModifyX(float v);
    void ModifyY(float v);

    float CalculateDistance(const Ponto& other) const;

    string getDataP() const;




private:
    float x;
    float y;


};

#endif //F4_EX1_PONTO_H