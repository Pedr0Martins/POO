#include "Triangulo.h"

string Triangulo::getDataT() const {
    string descricao = nome + ": ";
    int i;
    for (i = 0; i < 3; i++) {
        descricao += "(" + to_string(vertices[i].getX()) + "," + to_string(vertices[i].getY()) + ") ";
    }
    return descricao;

}

Ponto Triangulo::getVertice(int num) const {
    if(num >= 0 && num < 3){
        return vertices[num];
    }
    return Ponto(0,0);
}

void Triangulo::setVertice(int num, const Ponto &novoPonto) {
    if(num >= 0 && num < 3){
        vertices[num] = novoPonto;
    }
}

string Triangulo::getNome() const {
    return nome;
}

void Triangulo::setNome(const string &novoNome) {
    nome = novoNome;
}

Triangulo::Triangulo(const string &nome, const Ponto &p1, const Ponto &p2, const Ponto &p3): nome (nome), vertices{p1, p2, p3} {
    cout << "Triangulo criado: " << getDataT() << endl;
}

Triangulo::~Triangulo() {
    cout << "Triangulo destruido: " << getDataT() << endl;
}

