#include "Ponto.h"
#include "Triangulo.h"

int main() {
    Ponto p1(1, 1);
    Ponto p2(2, 2);
    Ponto p3(3, 3);

    Triangulo q("TrianguloQ", p1, p2, p3);

    cout << "Dados iniciais do Triangulo q: " << q.getDataT() << endl;

    return 0;
}
