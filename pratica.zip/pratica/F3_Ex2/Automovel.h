
#ifndef F3_EX2_AUTOMOVEL_H
#define F3_EX2_AUTOMOVEL_H

#endif //F3_EX2_AUTOMOVEL_H

#include <iostream>
using namespace std;

class Automovel {
public:
    Automovel(string matricula, string marca, string modelo,string combustivel);
    ~Automovel();

    bool LigarMotor();
    bool DesligarMotor() noexcept;
    string obtemDados() const;
    void acelerar(int valor = 7);
    void desacelerar(int valor);


private:
    string matricula;
    string marca;
    string modelo;
    string combustivel;

    bool motorEstaLigado = false;
    float combustivelNoTanque = 100;

    int velocidade = 0;

    static const int VELOCIDADE_MAXIMA = 120;
};