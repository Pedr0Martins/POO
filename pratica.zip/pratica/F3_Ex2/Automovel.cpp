#include "Automovel.h"

Automovel::Automovel(string matricula, string marca, string modelo, string combustivel) {
    this->matricula = matricula;
    this->marca = marca;
    this->modelo = modelo;
    this->combustivel = combustivel;

}

Automovel::~Automovel() {
    cout << "Automovel destruido" << endl;
}

bool Automovel::LigarMotor() {
    if(!motorEstaLigado){
        motorEstaLigado=true;
        return true;
    }else{
        cout << "Motor ja esta ligado" << endl;
        return false;
    }
}

bool Automovel::DesligarMotor() noexcept {
    if(motorEstaLigado){
        motorEstaLigado=false;
        return true;
    }else{
        cout << "Motor ja esta desligado" << endl;
        return false;
    }
}

string Automovel::obtemDados() const {
    return "Matricula: " + matricula + "\n" +
           "Marca: " + marca + "\n" +
           "Modelo: " + modelo + "\n" +
           "Combustivel: " + combustivel + "\n";
}

void Automovel::acelerar(int valor) {
    if(motorEstaLigado && velocidade>=0 && combustivelNoTanque>0 && valor<combustivelNoTanque && valor>0){
        velocidade+=valor;
        combustivelNoTanque-=valor;
    }else{
        cout << "Nao e possivel acelerar" << endl;
    }
}

void Automovel::desacelerar(int valor) {
    if(motorEstaLigado && velocidade>0 && combustivelNoTanque>0 && valor>0){
        velocidade-=valor;
    }else{
        cout << "Nao e possivel desacelerar" << endl;
    }
}
