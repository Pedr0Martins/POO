#include "Automovel.h"

int main() {
    Automovel A("00-00-00", "Audi", "A4", "Gasolina");
    string lista = A.obtemDados();
    cout << lista << endl;
    A.LigarMotor();
    A.LigarMotor();
    A.acelerar(9);
    A.desacelerar(5);


}
