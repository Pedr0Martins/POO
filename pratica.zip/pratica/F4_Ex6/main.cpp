#include "Pessoa.h"

int main() {

    Pessoa p1("Joao", 123456789, 12345678);
    cout << p1.getDescricao() << endl;

    return 0;
}
