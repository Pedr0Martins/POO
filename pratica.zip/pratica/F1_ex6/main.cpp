#include <iostream>
#include <sstream>
#include <fstream>
using namespace std;

int main() {
    string numerais[] = {"um", "dois", "tres", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez"};
    int input;
    cin >> input;

    if(cin.fail()){
        string s;
        cin >> s;
    }

    ifstream inputFile;


    inputFile.open("ficheiro.txt");
    if(!inputFile){
        return 1;
    }

    string linhas;
    getline(inputFile, linhas);



    inputFile.close();
    return 0;
}
