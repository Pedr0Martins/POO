#include <iostream>
#include <sstream>
using namespace std;

int main_v1() {
    string nome;
    int idade, i;
    cout << "Qual o seu nome?";
    getline(cin, nome);

    do{
        cout << "Qual a sua idade?";
        cin >> idade;
        if (idade < 0) {
            cout << "Idade invalida!" << endl;
        }
    } while (idade < 0);

    cout << "Ola " << nome << ", voce tem " << idade << " anos." << endl;
    cout << "O nome " << nome << " tem " << nome.length() << " caracteres." << endl;

    //imprimir cada caractere do nome em uma linha
    for (i = 0; i < nome.length(); i++) {
        cout << nome[i] << endl;
    }

    istringstream ss(nome);
    string token;
    while(ss >> token) {
        cout << token << endl;
        if(token == "Fernando") {
            cout << "Ja conheco o Fernando!" << endl;
        }
    }
    return 0;
}


int main() {
    string nome, aux;
    int i;
    //int j = 0;
    do{
        cout << "Qual o seu nome?";
        getline(cin, nome);
        if(nome == "fim") {
            break;
        }
        istringstream ss(nome);
        string token;
        while (ss >> token) {
            cout << token << endl;
            aux = ""; // Inicializa 'aux' como uma string vazia
            for (i = token.length() - 1; i >= 0; i--) {
                cout << token[i];
                aux += token[i]; // Adiciona o caracter à string 'aux'
                //aux[j] = token[i];
                //j++;
            }
            cout << endl; // Mova esta linha para fora do loop 'for'

            if (token == aux) {
                cout << "E palindromo!" << endl;
            }
        }

    }while(nome != "fim");

    return 0;
}



/*
        for(char c : nome) {   // for each (cada) char (caractere) c (em) nome
           cout << c << endl;
       }
*/