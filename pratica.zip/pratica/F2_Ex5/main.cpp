#include <iostream>
using namespace std;

int& seleciona(int& a, int& b, const char &c){
    if (c == 'm') {
        if(a < b) {
            return a;
        }else{
            return b;
        }
    }
    if (c == 'M') {
        if(a > b) {
            return a;
        }else{
            return b;
        }
    }
    throw range_error("Opcao invalida");
}



int main(){
    int a = 5, b = 10;
    seleciona(a, b, 'e') = 0;
    cout << "a = " << a << " b = " << b;

    return 0;
}
