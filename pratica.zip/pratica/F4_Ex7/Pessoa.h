#ifndef F4_EX6_PESSOA_H
#define F4_EX6_PESSOA_H

#include <iostream>
#include <string>
#include <sstream>
using namespace std;



class Pessoa {
public:
    Pessoa(string nome, int bi, int nif);
    //Pessoa();

    string getNome() const;
    void UpdateNome(string nome);

    int getNIF() const;
    int getBI() const;

    string getDescricao() const;

private:
    string nome;
    int nif;
    int bi;
};



#endif //F4_EX6_PESSOA_H
