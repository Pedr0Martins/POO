#include "RegistoCivil.h"

RegistoCivil::RegistoCivil(string country) : country(country), total_pessoas(0){}

string RegistoCivil::getCountry()  {
    return country;
}

int RegistoCivil::getNumPessoas() const {
    return total_pessoas;
}

bool RegistoCivil::addPessoa(Pessoa *p) {
    if(total_pessoas >= LIMITE){
        cout << "Limite de pessoas atingido." << endl;
        return false;
    }
    for (int i = 0; i < total_pessoas; i++) {
        if (pessoas[i]->getBI() == p->getBI() || pessoas[i]->getNIF() == p->getNIF()){
            cout << "Já existe uma pessoa com o mesmo BI." << endl;
            return false;
        }
    }
    pessoas[total_pessoas] = p;
    total_pessoas++;
    return true;
}

bool RegistoCivil::lePessoas(const string &filename) {
    ifstream file;
    string nome;
    int bi, nif;

    file.open(filename);
    if(!file.is_open()){
        cout << "Erro ao abrir o ficheiro." << endl;
        return false;
    }

    while(!file.eof()){
        getline(file, nome, ' ');
        file >> bi;
        file >> nif;
        Pessoa *p = new Pessoa(nome, bi, nif);
        addPessoa(p);
    }

    file.close();
    return true;
}

bool RegistoCivil::removePessoa(int bi) {
    for (int i = 0; i < total_pessoas; i++) {
        if (pessoas[i]->getBI() == bi) {
            pessoas[i] = pessoas[total_pessoas - 1];
            total_pessoas--;
            return true;
        }
    }
    return false;
}

string RegistoCivil::ObtemNomePessoa(int bi) {
    int i;
    for(i = 0; i < total_pessoas; i++){
        if(pessoas[i]->getBI() == bi){
            return pessoas[i]->getNome();
        }
    }
    return "Pessoa não encontrada.";
}

string RegistoCivil::ObtemPessoas() const {
    ostringstream oss;
    for(int i = 0; i < total_pessoas; i++){
        oss << pessoas[i]->getDescricao() << endl;
    }
    return oss.str();
}



int RegistoCivil::ObtemTotalPessoas() const {
    return total_pessoas;
}


