#ifndef F4_EX6_REGISTOCIVIL_H
#define F4_EX6_REGISTOCIVIL_H
#include "Pessoa.h"
#include <fstream>
class RegistoCivil {
public:
    RegistoCivil(string country);

    string getCountry();
    int getNumPessoas() const;
    bool addPessoa(Pessoa *p);
    bool lePessoas(const string& filename);
    bool removePessoa(int bi);
    string ObtemNomePessoa(int bi);
    string ObtemPessoas() const;
    int ObtemTotalPessoas() const;



private:
    string country;
    static const int LIMITE = 50;
    Pessoa *pessoas[LIMITE];
    int total_pessoas;

};




#endif //F4_EX6_REGISTOCIVIL_H
