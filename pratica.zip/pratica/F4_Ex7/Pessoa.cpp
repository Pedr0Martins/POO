#include "Pessoa.h"

Pessoa::Pessoa(string nome, int bi, int nif): nome(nome), bi(bi), nif(nif) {}

string Pessoa::getNome() const {
    return nome;
}

void Pessoa::UpdateNome(string nome) {
    this->nome = nome;
}

int Pessoa::getNIF() const {
    return nif;
}

int Pessoa::getBI() const {
    return bi;
}


string Pessoa::getDescricao() const {
    ostringstream oss;
    oss << "Nome: " << nome << " BI: " << bi << " NIF: " << nif << endl;
    return oss.str();
}

