#ifndef F7EX1_PONTO_H
#define F7EX1_PONTO_H
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
using namespace std;


class Ponto {
public:
    Ponto(int cx, int cy);
    ~Ponto();
private:
    int x,y;
};


#endif //F7EX1_PONTO_H
