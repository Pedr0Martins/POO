#include "Ponto.h"

int main_exa() {
    // Criando dinamicamente dois objetos Ponto

    // Apague os objetos no final, primeiro b, depois a
       /* Ponto* a = new Ponto(1, 2);
    Ponto* b = new Ponto(3, 4);
    delete b;
    delete a; */



    // Apague os objetos no final, primeiro a, depois b
       /*  Ponto* a = new Ponto(1, 2);
   Ponto* b = new Ponto(3, 4);
    delete a;
    delete b;*/



    // Não apague os objetos
       /*  Ponto* a = new Ponto(1, 2);
   Ponto* b = new Ponto(3, 4); */



    // Apague duas vezes o mesmo objeto a, sem tocar no ponteiro para ele
       /*   Ponto* a = new Ponto(1, 2);
    Ponto* b = new Ponto(3, 4);
    delete a;
    delete a; */



    // Apague duas vezes o mesmo objeto a tendo colocado o ponteiro para ele a nullptr
       /* Ponto* a = new Ponto(1, 2);
    delete a;
    a = nullptr;
    delete a; */

    // Impressão no ecrã de uma mensagem "\nfinal\n"*/
    cout << "\nfinal\n";

    return 0;
}

int main_exb() {
    //Cria um array de 3 objetos Ponto
    Ponto* array = new Ponto[3]{Ponto(1, 2), Ponto(3, 4), Ponto(5, 6)};

    // Libera a memória alocada para o array de objetos Ponto
    delete[] array;



    //outra solução
    Ponto ** array1 = new Ponto*[3];
    array1[0] = new Ponto(1, 2);
    array1[1] = new Ponto(3, 4);
    array1[2] = new Ponto(5, 6);

    // Libera a memória alocada para o array de ponteiros
    delete[] array1;


    return 0;
}

int main_exc(){
    int i, numPontos;

    cout << "Quantos pontos deseja criar? ";
    cin >> numPontos;

    Ponto** pontos = new Ponto*[numPontos];

    for (i = 0; i < numPontos; ++i) {
        int x, y;
        cout << "Digite as coordenadas para o ponto " << i + 1 << ": ";
        cin >> x >> y;
        pontos[i] = new Ponto(x, y);
    }

    // Libera a memória alocada para cada objeto Ponto
    for (i = 0; i < numPontos; ++i) {
        delete pontos[i];
    }

    // Libera a memória alocada para o array de ponteiros
    delete[] pontos;

    cout << "\nfinal\n";

    return 0;
}

int main_exd(){
    int numLinhas, numColunas;

    cout << "Quantas linhas deseja? ";
    cin >> numLinhas;
    cout << "Quantas colunas deseja? ";
    cin >> numColunas;


    Ponto*** matrizPonteiros = new Ponto**[numLinhas];
    for (int i = 0; i < numLinhas; ++i) {
        matrizPonteiros[i] = new Ponto*[numColunas];
        for (int j = 0; j < numColunas; ++j) {
            int x, y;
            cout << "Digite as coordenadas para o ponto " << i + 1 << "," << j + 1 << ": ";
            cin >> x >> y;
            matrizPonteiros[i][j] = new Ponto(x, y); // Criação de um Ponto
        }
    }

    // Liberação da memória alocada para a matriz bidimensional de ponteiros
    for (int i = 0; i < numLinhas; ++i) {
        for (int j = 0; j < numColunas; ++j) {
            delete matrizPonteiros[i][j];
        }
        delete[] matrizPonteiros[i];
    }
    delete[] matrizPonteiros;


    return 0;
}

int main(){
    //main_exa();
    //main_exb();
    //main_exc();
    main_exd();
    return 0;
}