#ifndef F8_EX7_CARTAO_H
#define F8_EX7_CARTAO_H

#include "Tarifario.h"

using namespace std;

class Tarifario;  // Declaração antecipada

class Cartao {
private:
    int numeroTelefone;
    double saldo;
    Tarifario *tarifario;

public:
    Cartao(int numeroTelefone, Tarifario *tarifario);

    bool autorizarChamada(int duracaoSegundos);

    void registarChamada(int duracaoSegundos);

    void fazerCarregamento(double quantia);

    int getNumeroTelefone() const;

    Tarifario* getTarifario() const;
};



#endif //F8_EX7_CARTAO_H
