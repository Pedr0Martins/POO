#include "Cartao.h"

Cartao::Cartao(int numeroTelefone, Tarifario *tarifario): numeroTelefone(numeroTelefone), tarifario(tarifario), saldo(0) {}

bool Cartao::autorizarChamada(int duracaoSegundos) {
    return tarifario->autorizarChamada(saldo, duracaoSegundos);
}

void Cartao::registarChamada(int duracaoSegundos) {
    double custo = tarifario->calcularCustoChamada(duracaoSegundos);

    saldo-= custo;
    cout << "Chamada Registada. Custo: " << custo << endl;

}

void Cartao::fazerCarregamento(double quantia) {
    if (tarifario->validarCarregamento(quantia)) {
        tarifario->aplicarBonus(quantia);
        saldo += quantia;
        cout << "Carregamento efetuado com sucesso. Saldo: " << saldo << endl;
    } else {
        cout << "Carregamento inválido." << endl;
    }
}

int Cartao::getNumeroTelefone() const {
    return numeroTelefone;
}

Tarifario* Cartao::getTarifario() const {
    return tarifario;
}
