#ifndef F4_EX8_CLUBE_H
#define F4_EX8_CLUBE_H

#include "RegistoCivil.h"

class Clube {
public:
    Clube(const string& name, const string& descricao);

    bool addSPessoa(Pessoa& p);
    Pessoa& removeSPessoa(const int& bi);
    bool verificaSocio(const int& bi) const;

    string ListarSocios() const;

private:
    static const int maxSocios = 50;
    string name;
    string descricao;
    int numSocios;
    Pessoa *socios[maxSocios];
};


#endif //F4_EX8_CLUBE_H
