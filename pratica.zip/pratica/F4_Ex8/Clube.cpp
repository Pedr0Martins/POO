#include "Clube.h"


Clube::Clube(const string &name, const string &descricao): name(name), descricao(descricao), numSocios(0){}

bool Clube::addSPessoa(Pessoa &p) {
    if(numSocios == maxSocios){
        return false;
    }
    for (int i = 0; i < numSocios; i++) {
        if(socios[i]->getBI() == p.getBI()){
            //já existe essa pessoa no array de socios
            return false;
        }
    }
    //adicionar a pessoa ao array de socios
    socios[numSocios] = &p;
    numSocios++;
    return true;
}

Pessoa &Clube::removeSPessoa(const int &bi) {
    for (int i = 0; i < numSocios; i++) {
        if (socios[i]->getBI() == bi) {
            for (int j = i; j < numSocios; j++) {
                socios[j] = socios[j+1];
            }
            numSocios--;
        }
    }
}

bool Clube::verificaSocio(const int &bi) const {
    //verificar se existe um socio com o bi passado por parametro
    for (int i = 0; i < numSocios; i++) {
        if(socios[i]->getBI() == bi){
            return true;
        }
    }
}

string Clube::ListarSocios() const {
    ostringstream oss;
    for (int i = 0; i < numSocios; i++) {
        oss << socios[i]->getDescricao() << endl;
    }
    return oss.str();
}
