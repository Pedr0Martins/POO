#include "Clube.h"

int main() {
    string s;
    RegistoCivil r("Portugal");
    Pessoa p1("Ana", 12345678, 123456789);
    Pessoa p2("Joao", 12345679, 123456788);
    Pessoa p3("Maria", 12345670, 123456787);
    r.addPessoa(&p1);
    r.addPessoa(&p2);
    r.addPessoa(&p3);
    r.lePessoas("addPessoa.txt");
   // s = r.ObtemPessoas();
   // cout << s << endl;

    Clube c("Clube de Futebol", "Clube de Futebol de Portugal");
    c.addSPessoa(p1);
    c.addSPessoa(p2);
    c.addSPessoa(p3);
    c.removeSPessoa(12345678); //p1
    s = c.ListarSocios();
    cout << s << endl;


    return 0;
}
