#include "Apressado.h"

double Apressado::calculaPagamento() {
    double valorTotal = 0.0;

    int tam = getTamanho();
    int *duracoes_treinos = getDuracoesTreinos();

    for(int i = 0; i < tam; i++){
        if(duracoes_treinos[i]<=10){
            valorTotal += 10.0;
        }else if(duracoes_treinos[i]<=20){
            valorTotal += 15.0;
        }else{
            valorTotal += 25.0;
        }
    }


    apagaTreinos();

    return valorTotal;
}
