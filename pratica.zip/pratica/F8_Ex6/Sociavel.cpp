#include "Sociavel.h"

Sociavel::Sociavel(const string& nome, int Bi, Tarifario* tarifario) : Cliente(nome, tarifario, Bi) {}


void Sociavel::reageSaida(const Cliente& outroCliente) {
    if (ginasioTemClientes() == false) {
        cout << "Cliente Sociavel a sair do ginásio, porque está sozinho" << endl;
    }
}