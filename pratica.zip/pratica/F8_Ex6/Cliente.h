#ifndef F8_EX6_CLIENTE_H
#define F8_EX6_CLIENTE_H

#include "Tarifario.h"

class Cliente {
public:
    Cliente(string nome, Tarifario *tarifario, int Bi);

    void IniciaTreino(int hora);

    void TerminaTreino(int hora);

    int getBi() const {
        return Bi;
    }

    double paga();

    // Métodos virtuais puros que devem ser implementados em classes derivadas
    virtual void reageEntrada(const Cliente& outroCliente) = 0;
    virtual void reageSaida(const Cliente& outroCliente) = 0;

    // Destrutor virtual para garantir chamada correta do destrutor nas classes derivadas
    virtual ~Cliente() = default;

    // Regra do zero e exclusão do operador de cópia e atribuição para evitar cópias e atribuições
    Cliente(const Cliente&) = delete;
    Cliente& operator=(const Cliente&) = delete;

private:
    string nome;
    Tarifario *tarifario;
    int Bi;
    int horaInicioTreino;
};


#endif //F8_EX6_CLIENTE_H
