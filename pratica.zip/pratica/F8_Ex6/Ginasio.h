#ifndef F8_EX6_GINASIO_H
#define F8_EX6_GINASIO_H

#include "Cliente.h"
#include <algorithm>
#include <memory>

class Ginasio {
public:
    Ginasio();

    void PassarMinutos(int minutos);

    void AdicionaCliente(const Cliente& cliente);

    void RemoveCliente(int bi);

    void ClienteEntra(int bi);

    void ClienteSai(int bi);

    double PagarConta(int bi);

private:
    vector<Cliente> clientes;
    int relogio;
};


#endif //F8_EX6_GINASIO_H
