#ifndef F8_EX6_TARIFARIO_H
#define F8_EX6_TARIFARIO_H

#include <vector>
#include <string>
#include <iostream>

using namespace std;

class Tarifario {
public:
    Tarifario();
    void AcrescentaTreino(int duracao);

    virtual double calculaPagamento() = 0;

    //obter o array de durações de treinos
    int *getDuracoesTreinos() const {
        return duracoes_treinos;
    }

    //obter o tamanho do array de durações de treinos
    int getTamanho() const {
        return tamanho;
    }



private:
    int tamanho;
    int *duracoes_treinos;
    int capacidade = 10;

protected:
    // Método para apagar as durações de todos os treinos
    void apagaTreinos(){
        // Apaga as durações de todos os treinos
        for(int i = 0; i < tamanho; i++){
            duracoes_treinos[i] = 0;
        }
    }
};


#endif //F8_EX6_TARIFARIO_H
