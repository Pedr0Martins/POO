#ifndef F8_EX6_SOCIAVEL_H
#define F8_EX6_SOCIAVEL_H

#include "Cliente.h"
#include <memory>

class Sociavel: public Cliente {
public:
    Sociavel(const string& nome, int BI, Tarifario* tarifario);

    void reageEntrada(const Cliente& outroCliente) override;

    void reageSaida(const Cliente& outroCliente) override;

private:

    // Método privado para verificar se há clientes no ginásio (além do próprio cliente)
    bool ginasioTemClientes() const {
        // Adicione aqui a lógica para verificar se há clientes no ginásio
        // Retorna true se há outros clientes, false caso contrário
        return false;
    }
};


#endif //F8_EX6_SOCIAVEL_H
