#include "Tarifario.h"

void Tarifario::AcrescentaTreino(int duracao) {
    if (tamanho < capacidade) {
        duracoes_treinos[tamanho] = duracao;
        tamanho++;
    } else {
        cout << "Não é possível acrescentar mais treinos!" << endl;
    }
}

Tarifario::Tarifario() : tamanho(0), duracoes_treinos(new int[10]), capacidade(10) {}
