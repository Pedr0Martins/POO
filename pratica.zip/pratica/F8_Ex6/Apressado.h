#ifndef F8_EX6_APRESSADO_H
#define F8_EX6_APRESSADO_H

#include "Tarifario.h"

class Apressado : public Tarifario {
public:
    double calculaPagamento() override;
};


#endif //F8_EX6_APRESSADO_H
