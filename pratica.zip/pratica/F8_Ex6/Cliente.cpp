#include "Cliente.h"

Cliente::Cliente(string nome, Tarifario *tarifario, int Bi): nome(nome), tarifario(tarifario), Bi(Bi) {}

void Cliente::IniciaTreino(int hora) {
    horaInicioTreino = hora;
}

void Cliente::TerminaTreino(int hora) {
    int duracao = hora - horaInicioTreino;
    tarifario->AcrescentaTreino(duracao);
}

double Cliente::paga() {
    return tarifario->calculaPagamento();
}
