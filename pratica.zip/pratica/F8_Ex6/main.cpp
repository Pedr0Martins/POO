#include "Apressado.h"

int main() {
// Exemplo de utilização da classe Apressado
    Apressado tarifarioApressado;

    // Adicionar durações de treinos
    tarifarioApressado.AcrescentaTreino(8);
    tarifarioApressado.AcrescentaTreino(15);
    tarifarioApressado.AcrescentaTreino(25);

    // Calcular o pagamento conforme as regras do tarifário Apressado
    double pagamentoApressado = tarifarioApressado.calculaPagamento();

    // Exibir o valor a pagar para o tarifário Apressado
    cout << "Valor a pagar (Apressado): " << pagamentoApressado << endl;

    return 0;
}
