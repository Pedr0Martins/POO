#include "Ginasio.h"

Ginasio::Ginasio() : relogio(0) {}

void Ginasio::PassarMinutos(int minutos) {
    relogio += minutos;
}

void Ginasio::AdicionaCliente(const Cliente &cliente) {
    clientes.push_back(cliente);
}

void Ginasio::RemoveCliente(int bi) {
    for (auto it = clientes.begin(); it != clientes.end(); it++) {
        if (it->getBi() == bi) {
            clientes.erase(it);
            break;
        }
    }
}

void Ginasio::ClienteEntra(int bi) {

}

void Ginasio::ClienteSai(int bi) {

}

double Ginasio::PagarConta(int bi) {
    return 0;
}
