#include <iostream>

using namespace std;

const int TAMANHO_MATRIZ = 3;


struct Tabela {
    int matriz[TAMANHO_MATRIZ];
};


void preencherMatriz(Tabela& tabela, int valor) {
    for (int i = 0; i < TAMANHO_MATRIZ; i++) {
            tabela.matriz[i] = valor;
    }
}


void listarConteudo(const Tabela& tabela) {
    for (int i = 0; i < TAMANHO_MATRIZ; i++) {
            cout << tabela.matriz[i] << " ";
        cout << endl;
    }
}

int obterValor(const Tabela& tabela, int linha) {
    if(linha < 0 || linha >= TAMANHO_MATRIZ) {
        throw out_of_range("Posicao invalida");
    }else{
        return tabela.matriz[linha];
    }
}


bool atualizaTabela(Tabela tabela, int linha,  int valor){
    if(linha < 0 || linha >= TAMANHO_MATRIZ) {
        cout << "Posicao invalida" << endl;
        return false;
    }else{
        tabela.matriz[linha] = valor;
        return true;
    }
}

int &elementoEm(Tabela& tabela, int linha){
    if(linha < 0 || linha >= TAMANHO_MATRIZ) {
        throw out_of_range("Posicao invalida");
    }else{
        return tabela.matriz[linha];
    }
}




int main() {
    Tabela a;
    int i;

    preencherMatriz(a, 42);

    listarConteudo(a);

    i = obterValor(a, 1);
    cout << "Valor: " << i << endl;

    cout << elementoEm(a, 10); // aparece um determinado valor
    elementoEm(a,10) = 15; // notar que a chamada à função fica do lado esquerdo da atribuição
     cout << elementoEm(a, 10); // aparece 15



    return 0;
}
