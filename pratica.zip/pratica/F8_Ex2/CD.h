#ifndef F8_EX2_CD_H
#define F8_EX2_CD_H

#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <memory>

using namespace std;

class CD {
public:
    CD(string titulo);

    void acrescentaFaixa(string faixa);

    virtual string ObtemDescricao() const;

    virtual string play() const;

    string obterTitulo() const;

    friend ostream& operator<<(std::ostream& os, const CD& cd);

private:
    string titulo;
    vector<string> faixas;
};


#endif //F8_EX2_CD_H
