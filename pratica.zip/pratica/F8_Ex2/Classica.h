#ifndef F8_EX2_CLASSICA_H
#define F8_EX2_CLASSICA_H

#include "CD.h"


class Classica:public CD {
public:
    Classica(string titulo, string nomeMaestro, string Compositor);

    string ObtemDescricao() const override;

    string play() const override;

private:
    string nomeMaestro;
    string Compositor;
};


#endif //F8_EX2_CLASSICA_H
