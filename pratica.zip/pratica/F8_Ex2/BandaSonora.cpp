#include "BandaSonora.h"

BandaSonora::BandaSonora(string titulo, string nomeFilme):CD(titulo), nomeFilme(nomeFilme) {}

string BandaSonora::ObtemDescricao() const {
    stringstream oss;
    oss << CD::ObtemDescricao() << endl;
    oss << "Nome do Filme: " << nomeFilme << endl;
    return oss.str();
}

string BandaSonora::play() const {
    stringstream oss;
    oss << CD::obterTitulo() << " - " << nomeFilme << " ja nao se fazem filmes como dantes" << endl;
    return oss.str();
}
