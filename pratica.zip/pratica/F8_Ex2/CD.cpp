#include "CD.h"

CD::CD(string titulo): titulo(titulo) {}

void CD::acrescentaFaixa(string faixa) {
    faixas.push_back(faixa);
}

string CD::ObtemDescricao() const {

    stringstream oss;
    oss << "CD: " << titulo << endl;
    for (int i = 0; i < faixas.size(); i++) {
        oss << "Faixa " << i + 1 << ": " << faixas[i] << endl;
    }
    return oss.str();
}

string CD::play() const {
    stringstream oss;
    oss << "A tocar o CD: " << titulo << endl;

    return oss.str();
}

string CD::obterTitulo() const {
    return titulo;
}

ostream &operator<<(ostream &os, const CD &cd) {
    os << cd.ObtemDescricao();
    return os;
}