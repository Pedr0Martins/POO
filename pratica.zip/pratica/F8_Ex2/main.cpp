#include "CD.h"
#include "Classica.h"
#include "BandaSonora.h"
#include "ColecaoCD.h"

int main() {
    ColecaoCD minhaColecao;

    Classica cdClassica("Sinfonia n 9", "Beethoven", "Beethoven");
    BandaSonora cdBandaSonora("Trilha Sonora do Filme", "Filme");

    minhaColecao.acrescentaCD(&cdClassica);
    minhaColecao.acrescentaCD(&cdBandaSonora);

    // Exibe informações sobre todos os CDs da coleção
    cout << minhaColecao;

    return 0;
}
