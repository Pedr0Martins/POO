#ifndef F8_EX2_BANDASONORA_H
#define F8_EX2_BANDASONORA_H

#include "CD.h"

class BandaSonora:public CD {
public:
    BandaSonora(string titulo, string nomeFilme);

    string ObtemDescricao() const override;

    string play() const override;

private:
    string nomeFilme;
};


#endif //F8_EX2_BANDASONORA_H
