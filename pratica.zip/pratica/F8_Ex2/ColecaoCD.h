#ifndef F8_EX2_COLECAOCD_H
#define F8_EX2_COLECAOCD_H

#include "CD.h"

class ColecaoCD {
public:
    ~ColecaoCD();
    void acrescentaCD(CD *cd);

    // fUNCAO para obter o vector de cds
    vector<CD*> obterCds() const;

    string ObtemDescricao() const;

    // Função para exibir informações sobre todos os CDs da coleção

private:
    vector<CD*> cds;
};

ostream& operator<<(ostream& os, const ColecaoCD& colecao);

#endif //F8_EX2_COLECAOCD_H
