#include "ColecaoCD.h"



void ColecaoCD::acrescentaCD(CD *cd) {
    //adicionar um cd à coleção
    cds.push_back(cd);
}

std::ostream &operator<<(std::ostream &os, const ColecaoCD &colecao) {

    for (const auto& cd : colecao.obterCds()) {
        os << *cd << "\n";
    }
    return os;
}

//quando a coleção for destruida, os cds também serão
ColecaoCD::~ColecaoCD() {
    cout << "Colecao destruida" << endl;
}

string ColecaoCD::ObtemDescricao() const {
    stringstream oss;
    for (const auto &cd : cds) {
        oss << cd->ObtemDescricao() << endl;
    }
    return oss.str();
}

vector<CD *> ColecaoCD::obterCds() const {
    return cds;
}
