//
// Created by asus on 29/11/2023.
//

#include "Classica.h"

Classica::Classica(string titulo, string nomeMaestro, string Compositor):CD(titulo), nomeMaestro(nomeMaestro), Compositor(Compositor) {}

string Classica::ObtemDescricao() const {
    //usa stringstream para criar uma string com a descrição do CD
    stringstream oss;
    oss << CD::ObtemDescricao() << endl;
    oss << "Maestro: " << nomeMaestro << endl;
    oss << "Compositor: " << Compositor << endl;
    return oss.str();
}

string Classica::play() const {
    stringstream oss;
    oss << "A tocar boa musica: " << nomeMaestro << "-" << CD::obterTitulo() << endl;
    return oss.str();
}
