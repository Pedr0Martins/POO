#include "MSG.h"

int main() {
    MSG a('a');
    MSG b;
    MSG &c = b;

    cout << a.getInfo() << endl;
    cout << b.getInfo() << endl;
    cout << c.getInfo() << endl;

 /*   MSG m;
    m.teste(); */

    MSG &m1 = a.teste1();

    m1.teste1();

    cout << m1.getInfo() << endl;
    return 0;
}
