#include "MSG.h"


MSG::MSG(char letter)  {
    this->letter = letter;
    this->number = getNextNumber();
    //Escreve o conteudo do objeto criado
    cout << "MSG " << this->number << " created" << endl;
}

MSG::~MSG() {
    //Escreve o conteudo do objeto destruido
    cout << "MSG " << this->number << " destroyed" << endl;
}

string MSG::getInfo() const{
    return "MSG " + to_string(this->number) + ": " + this->letter;
}

/*void MSG::teste(MSG &obj) {
}*/

MSG::MSG(const MSG &z) {
    this->letter = z.letter;
    this->number = getNextNumber();
    cout << "Copy constructor called" << endl;
}

MSG MSG::teste() {
    MSG aux('y');
    return aux;
}


MSG aux('y'); // Crie o objeto 'aux' fora da função 'teste1'

MSG &MSG::teste1() {
    return aux;
}