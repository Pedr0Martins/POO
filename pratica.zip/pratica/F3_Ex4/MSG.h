#include <iostream>
#include <string>

using namespace std;


class MSG {

public:
    MSG(char letter = 'x');

    ~MSG();

    string getInfo() const;


    MSG(const MSG &z);


    MSG teste();

    MSG &teste1();

private:
    char letter;
    int number;
    static int getNextNumber() {
        static int nextNumber = 1;
        return nextNumber++;
    }
};
