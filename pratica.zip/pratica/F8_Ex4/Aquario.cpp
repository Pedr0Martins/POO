#include "Aquario.h"

void Aquario::adicionarPeixe(Peixe *peixe) {
    peixes.push_back(peixe);
}

Aquario &Aquario::getInstance() {
    static Aquario instance;
    return instance;
}

void Aquario::removerPeixe(int id) {
    for (int i = 0; i < peixes.size(); i++) {
        if (peixes[i]->getID() == id) {
            peixes.erase(peixes.begin() + i);
            break;
        }
    }
}

int Aquario::obterIDPeixeAleatorio(int idAtual) {
    for(const auto& peixe : peixes) {
        if (peixe->getID() != idAtual) {
            return peixe->getID();
        }
    }
    return -1;
}

Peixe *Aquario::obterPeixePorID(int id) {
    for (const auto& peixe : peixes) {
        if (peixe->getID() == id) {
            return peixe;
        }
    }
    return nullptr;
}

void Aquario::alimentarPeixes(int quantidade) {
    for (auto& peixe : peixes) {
        peixe->alimentar(quantidade);
    }
}

ostream &operator<<(ostream &os, const Aquario &aquario) {
    for (const auto& peixe : aquario.peixes) {
        os << *peixe << endl;
    }
    return os;
}