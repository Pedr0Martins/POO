#ifndef F8_EX4_CARPA_H
#define F8_EX4_CARPA_H

#include "Peixe.h"
#include "Aquario.h"

class Carpa: public Peixe {
public:
    Carpa(string cor);

    void alimentar(int quantidade) override;

    string getEspecie() const override;

    Peixe* duplica() override;

private:
    string nome;
    string cor_c;
    int peso;
    int id;
    int quantidadeComida = 0;

};


#endif //F8_EX4_CARPA_H
