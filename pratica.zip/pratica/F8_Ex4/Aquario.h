#ifndef F8_EX4_AQUARIO_H
#define F8_EX4_AQUARIO_H

#include "Peixe.h"

class Aquario {
private:
    vector<Peixe*> peixes;

    Aquario() {} // Construtor privado para garantir que apenas uma instância pode ser criada
public:
    static Aquario& getInstance();
    void adicionarPeixe(Peixe* peixe);

    void removerPeixe(int id);

    int obterIDPeixeAleatorio(int idAtual);
    Peixe* obterPeixePorID(int id);
    void alimentarPeixes(int quantidade);
    friend ostream& operator<<(ostream& os, const Aquario& aquario);
};


#endif //F8_EX4_AQUARIO_H
