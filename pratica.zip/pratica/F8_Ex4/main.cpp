#include "Aquario.h"
#include "Carpa.h"
#include "Tubarao.h"

int main() {
// Exemplo de uso
    Carpa carpa1("Dourada");

    Aquario::getInstance().adicionarPeixe(&carpa1);

    cout << "Aquário Inicial:" << endl;
    cout << Aquario::getInstance() << endl;

    Aquario::getInstance().alimentarPeixes(30);

    cout << "Aquário após alimentação:" << endl;
    cout << Aquario::getInstance() << endl;

    return 0;
}
