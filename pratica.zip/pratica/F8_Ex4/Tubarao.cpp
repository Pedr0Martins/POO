#include "Tubarao.h"

Tubarao::Tubarao(string cor_t): Peixe(cor_t, 15) {}


void Tubarao::alimentar(int quantidade) {
    if (peso > 20) {
        peso--;
    } else if (peso > 5) {
        // Procura outro peixe para comer
        int idOutroPeixe = Aquario::getInstance().obterIDPeixeAleatorio(getID());
        Peixe* outroPeixe = Aquario::getInstance().obterPeixePorID(idOutroPeixe);

        if (outroPeixe != nullptr) {
            peso += outroPeixe->getPeso();
            Aquario::getInstance().removerPeixe(idOutroPeixe);
        }
    } else {
        peso -= 2;
        if (peso < 5) {
            // Tubarão morre
            Aquario::getInstance().removerPeixe(getID());
        }
    }
}
