#include "Carpa.h"

Carpa::Carpa(string cor_c) : Peixe( cor_c, 5){}

void Carpa::alimentar(int quantidade) {
    peso += quantidade;
    if (peso > 50) {
        peso = 20;
        // Adiciona uma nova Carpa ao aquário
        Aquario::getInstance().adicionarPeixe(new Carpa(cor_c));
    }
}

string Carpa::getEspecie() const {
    return "Carpa";
}

Peixe* Carpa::duplica() {
    return new Carpa(*this);
}
