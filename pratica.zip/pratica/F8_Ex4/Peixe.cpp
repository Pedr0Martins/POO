#include "Peixe.h"

Peixe::Peixe( string cor, int peso) : cor(cor), peso(peso), ID(proximoID++), especie(especie) {};


ostream& operator<<(ostream& os, const Peixe& peixe) {
    os << "ID: " << peixe.ID << ", Espécie: " << peixe.especie
       << ", Cor: " << peixe.cor << ", Peso: " << peixe.peso << "g";
    return os;
}

int Peixe::getID() const {
    return ID;
}

int Peixe::getPeso() const {
    return peso;
}
