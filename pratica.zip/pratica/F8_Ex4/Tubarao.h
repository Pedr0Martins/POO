#ifndef F8_EX4_TUBARAO_H
#define F8_EX4_TUBARAO_H

#include "Peixe.h"
#include "Aquario.h"

class Tubarao: public Peixe {
public:
    Tubarao(string cor);

    void alimentar(int quantidade) override;

private:
    string nome;
    string cor_t;
    int peso;
    int id;
    int quantidadeComida = 0;
};


#endif //F8_EX4_TUBARAO_H
