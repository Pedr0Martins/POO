#ifndef F8_EX4_PEIXE_H
#define F8_EX4_PEIXE_H

#include <iostream>
#include <vector>
#include <memory>

using namespace std;

class Peixe {
private:
    static int proximoID;
    int ID;
    std::string especie;
    std::string cor;
    int peso;

public:
    Peixe(string cor, int peso);


    virtual void alimentar(int quantidade) = 0;

    friend ostream& operator<<(ostream& os, const Peixe& peixe);

    virtual string getEspecie() const = 0;

    int getID() const;
    int getPeso() const;
    virtual Peixe* duplica() = 0;
};

int Peixe::proximoID = 1000;


#endif //F8_EX4_PEIXE_H
