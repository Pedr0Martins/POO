#include "Clube.h"

int main() {
    RegistoCivil registo("Portugal");
    Pessoa p1("Ana Santos", 12345, 11111);
    Pessoa p2("Carlos Silva", 54321, 22222);

    registo.adicionarPessoa(p1);
    registo.adicionarPessoa(p2);


    cout << "Listagem de Pessoas:\n" << registo.listarPessoas() << endl;

    cout << "Nome da pessoa com BI 12345: " << registo.getNomePorBI(12345) << endl;

    registo.atualizarNomePorBI(12345, "Joao Silva");

    cout << "Listagem de Pessoas apos a atualizacao:\n" << registo.listarPessoas() << endl;

    cout << "Numero de pessoas no registo: " << registo.getNumeroDePessoas() << endl;

    const Pessoa* pessoaPtr = registo.getPessoaPorBI(54321);
    if (pessoaPtr) {
        cout << "Informacoes da Pessoa com BI 54321: " << pessoaPtr->descricao() << endl;
    } else {
        cout << "Pessoa nao encontrada." << endl;
    }

    return 0;
}
