//#include "RegistoCivil.h"
#include "RegistoCivil.h"

RegistoCivil::RegistoCivil(string nomePais): nomePais(nomePais) {}

string RegistoCivil::getNomePais() const {
    return nomePais;
}

bool RegistoCivil::adicionarPessoa(const Pessoa &p) {
    int i;
    //verifica se a pessoa já existe no Registo Civil
    for (i = 0; i < pessoas.size(); i++) {
        if (pessoas[i]->getBI() == p.getBI()) {
            return false;
        }
    }
    //adiciona a pessoa ao vetor de ponteiros para Pessoa
    pessoas.push_back(new Pessoa(p));
    return true;
}

RegistoCivil::~RegistoCivil() {
    int i;
    //liberta a memória alocada para cada Pessoa
    for (i = 0; i < pessoas.size(); i++) {
        delete pessoas[i];
    }
}

string RegistoCivil::getNomePorBI(int bi) const {
    int i;
    //verifica se a pessoa existe no Registo Civil
    for (i = 0; i < pessoas.size(); i++) {
        if (pessoas[i]->getBI() == bi) {
            return pessoas[i]->getNome();
        }
    }
    return "BI inexistente";
}

string RegistoCivil::listarPessoas() const {
    //obter a lista de pessoas do Registo Civil numa string
    ostringstream oss;
    int i;
    for (i = 0; i < pessoas.size(); i++) {
        oss << pessoas[i]->descricao() << endl;
    }
    return oss.str();

}

void RegistoCivil::atualizarNomePorBI(int bi, string novoNome) {
    //atualiza o nome da pessoa com o BI indicado
    int i;
    for (i = 0; i < pessoas.size(); i++) {
        if (pessoas[i]->getBI() == bi) {
            pessoas[i]->setNome(novoNome);
            cout << "Nome atualizado com sucesso" << endl;
            return;
        }
    }

}

int RegistoCivil::getNumeroDePessoas() const {
    return pessoas.size();
}

Pessoa *RegistoCivil::getPessoaPorBI(int bi) {
    //retorna um ponteiro constante para a pessoa com o BI indicado, usando find_if
    vector<Pessoa *>::const_iterator it = find_if(pessoas.begin(), pessoas.end(), [bi](Pessoa *p) {
        return p->getBI() == bi;
    });

    if (it != pessoas.end()) {
        return *it;
    }

    return nullptr;
}

