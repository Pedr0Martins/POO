#ifndef F4_EX1_PONTO_H
#define F4_EX1_PONTO_H

#include <iostream>
#include <string>
#include <cmath>

using namespace std;


class Ponto {
public:
    Ponto(); // assumir int x = 0, int y = 0
    Ponto(float x, float y);

    float getX() const;
    float getY() const;

    void ModifyX(float v);
    void ModifyY(float v);

    float CalculateDistance(const Ponto& other) const;

    string getData() const;




private:
    float x;
    float y;


};

#endif //F4_EX1_PONTO_H