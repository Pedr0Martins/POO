#include "Ponto.h"


Ponto::Ponto() {
    this->x = 0;
    this->y = 0;
}

Ponto::Ponto(float x, float y) {
    this->x = x;
    this->y = y;
}

float Ponto::getX() const {
    return x;
}

float Ponto::getY() const {
    return y;
}

void Ponto::ModifyX(float v) {
    this->x+=v;
}

void Ponto::ModifyY(float v) {
    this->y+=v;
}

float Ponto::CalculateDistance(const Ponto& other) const{
    float deltaX = other.getX() - x;
    float deltaY = other.getY() - y;
    return sqrt(deltaX * deltaX + deltaY * deltaY);
}

string Ponto::getData() const {
    return "x: " + to_string(x) + " y: " + to_string(y);
}

