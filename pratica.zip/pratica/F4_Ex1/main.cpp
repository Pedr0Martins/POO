#include "Ponto.h"

int main() {
    int i;
    //matriz de 3 objetos da classe Ponto
    Ponto pontos[3] = {Ponto(1, 2), Ponto(2, 4), Ponto(5, 7)};
    Ponto pontos1[3] = {Ponto(), Ponto(), Ponto()};

    for(i = 0; i < 3; i++){
        cout << pontos[i].getData() << endl;
    }

    cout << endl;

    for(i = 0; i < 3; i++){
        cout << pontos1[i].getData() << endl;
    }





/*    const Ponto p1(5,6);
    Ponto p(1, 2);
    Ponto p2(3, 4);


    cout << p.getData() << endl;
    cout << p2.getData() << endl;
    cout << p1.getData() << endl;

    float i = p.CalculateDistance(p2);
    cout << i << endl;*/

    return 0;
}
