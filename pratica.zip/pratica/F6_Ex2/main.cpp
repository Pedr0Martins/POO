#include "RegistoCivil.h"

int main() {
    RegistoCivil registo("Portugal");
    Pessoa pessoa1("João", 12345, 54321);
    Pessoa pessoa2("Maria", 12346, 54322);

    // iii. Obtenha e armazene o ponteiro para essa pessoa
    const Pessoa* ptrPessoa1 = registo.getPessoa(pessoa1.getBI());

    // iv. Insira uma nova pessoa.
    registo.AddPessoa(pessoa2);

    // v. Obtenha o nome da primeira pessoa através do ponteiro que armazenou
    if (ptrPessoa1 != nullptr) {
        std::cout << "Nome da primeira pessoa: " << ptrPessoa1->getNome() << std::endl;
    } else {
        std::cout << "Pessoa nao encontrada." << std::endl;
    }


    // Exemplo de inserção e remoção (prossiga até ocorrer um erro):
    registo.AddPessoa(Pessoa("Ana", 67890, 98765));
    registo.AddPessoa(Pessoa("Ana", 67890, 98765));
    registo.delPessoa(12346); // Remover a pessoa adicionada anteriormente

    // Continue adicionando e removendo pessoas até que ocorra um erro.

    return 0;

}
