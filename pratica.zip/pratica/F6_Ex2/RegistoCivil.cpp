#include "RegistoCivil.h"

RegistoCivil::RegistoCivil(const string &pais): pais(pais){}

string RegistoCivil::getPais() const {
    return pais;
}

void RegistoCivil::AddPessoa(const Pessoa &p1) {
    int i;
    //verificar se a pessoa ja existe no registo
    for (i = 0; i < pessoas.size(); i++) {
        if (pessoas[i].getBI() == p1.getBI()) {
            cout << "Pessoa ja existe no registo" << endl;
            return;
        }
    }
    //adiciona a pessoa ao vector
    pessoas.push_back(p1);

    //adiciona a pessoa ao set
    pessoasSet.insert(p1);

    //adiciona a pessoa ao unordered_map
    biToPessoa.insert(make_pair(p1.getBI(), p1));

    //adiciona a pessoa ao map
    biToPessoa2.insert(make_pair(p1.getBI(), p1));

    //incrementar o numero de pessoas
    numPessoas++;
}

void RegistoCivil::AddPessoas(const string &fich) {
    //adicionar pessoas a partir de um ficheiro de texto com o formato "nome bi nif"
    ifstream ficheiro;
    ficheiro.open(fich);
    if (ficheiro.is_open() && ficheiro.good()) {
        string nome;
        int bi, nif;
        while (!ficheiro.eof()) {
            ficheiro >> nome >> bi >> nif;
            Pessoa p1(nome, bi, nif);
            AddPessoa(p1);

        }
        ficheiro.close();
    }
    else {
        cout << "Erro ao abrir o ficheiro" << endl;
    }
}

void RegistoCivil::exportar(const string &fich) const {
    int i;
    //exportar para um ficheiro de texto todas as pessoas
    ofstream ficheiro;
    ficheiro.open(fich);
    if (ficheiro.is_open() && ficheiro.good()) {
        for (i = 0; i < pessoas.size(); i++) {
            ficheiro << pessoas[i].getNome() << " " << pessoas[i].getBI() << " " << pessoas[i].getNIF() << endl;
        }
        ficheiro.close();
    }
    else {
        cout << "Erro ao abrir o ficheiro" << endl;
    }
}

void RegistoCivil::delPessoa(int bi) {
    int i;
    if(pessoas.empty()){
        cout << "Nao existem pessoas no registo" << endl;
        return;
    }
    for (i = 0; i < pessoas.size(); i++) {
        if (pessoas[i].getBI() == bi) {
            pessoas.erase(pessoas.begin() + i);
            //elimina a pessoa do set
            pessoasSet.erase(pessoasSet.find(pessoas[i]));
            //elimina a pessoa do unordered_map
            biToPessoa.erase(bi);
            numPessoas--;
            return;
        }
    }
}

string RegistoCivil::getName(int bi) const {
    int i;
    if(pessoas.empty()){
        return "Nao existem pessoas no registo";
    }

    for (i = 0; i < pessoas.size(); i++) {
        if (pessoas[i].getBI() == bi) {
            return pessoas[i].getNome();
        }
    }
    return "Nao existe nenhuma pessoa com esse BI";
}

string RegistoCivil::listaPessoas() const {
    //listagem das pessoas numa string usando stringstream
    int i;
    ostringstream oss;
    if(pessoas.empty()){
        oss << "Nao existem pessoas no registo";
        return oss.str();
    }
    for (i = 0; i < pessoas.size(); i++) {
        oss << pessoas[i].getNome() << " " << pessoas[i].getBI() << " " << pessoas[i].getNIF() << endl;
    }
    return oss.str();
}

void RegistoCivil::updateName(int bi, const string &nome) {
    int i;
    if(pessoas.empty()){
        cout << "Nao existem pessoas no registo" << endl;
        return;
    }
    for (i = 0; i < pessoas.size(); i++) {
        if (pessoas[i].getBI() == bi) {
            pessoas[i].setNome(nome);
            return;
        }
    }
    cout << "Nao existe nenhuma pessoa com esse BI" << endl;
}

int RegistoCivil::getNumPessoas() const {
    return numPessoas;
}

int RegistoCivil::getNumPessoas(const string &nome) const {
    int i, num = 0;
    if(pessoas.empty()){
        return 0;
    }
    for (i = 0; i < pessoas.size(); i++) {
        if (pessoas[i].getNome().find(nome) != string::npos) {
            num++;
        }
    }
    return num;
}

void RegistoCivil::delPessoas(int bi1, int bi2) {
    for(vector<Pessoa>::iterator it = pessoas.begin(); it != pessoas.end(); it++){
        if(it->getBI() >= bi1 && it->getBI() <= bi2){
            pessoas.erase(it);
            pessoasSet.erase(pessoasSet.find(*it));
            biToPessoa.erase(it->getBI());
            numPessoas--;
        }
    }



    //percorre o set e apaga as pessoas cujo BI esteja entre bi1 e bi2
    /*for(set<Pessoa>::iterator it = pessoasSet.begin(); it != pessoasSet.end(); it++){
        if(it->getBI() >= bi1 && it->getBI() <= bi2){
            pessoasSet.erase(it);
        }
    }*/

    //percorre o unordered_map e apaga as pessoas cujo BI esteja entre bi1 e bi2
   /* for(unordered_map<int, Pessoa>::iterator it = biToPessoa.begin(); it != biToPessoa.end(); it++){
        if(it->first >= bi1 && it->first <= bi2){
            biToPessoa.erase(it);
        }
    }*/
}

void RegistoCivil::delAllPessoas() {
    pessoas.clear();
    pessoasSet.clear();
    biToPessoa.clear();
    numPessoas = 0;
}

Pessoa *RegistoCivil::getPessoa(int bi) {
    if(biToPessoa.find(bi) != biToPessoa.end()){
        return &biToPessoa.at(bi);
    }
    return nullptr;
}

