#ifndef F6_EX2_REGISTOCIVIL_H
#define F6_EX2_REGISTOCIVIL_H

#include "Pessoa.h"

class RegistoCivil {
public:
    RegistoCivil(const string &pais);
    string getPais() const;
    void AddPessoa(const Pessoa &p1);

    //adicionar pessoas a partir de um ficheiro de texto
    void AddPessoas(const string &fich);

    //exportar para um ficheiro de texto todas as pessoas
    void exportar(const string &fich) const;

    //apagar uma pessoa dado o seu BI
    void delPessoa(int bi);

    //obter o nome de uma pessoa dado o seu BI
    string getName(int bi) const;

    //listagem das pessoas numa string
    string listaPessoas() const;

    //atualizar o nome de uma pessoa dado o seu BI
    void updateName(int bi, const string &nome);

    //obter o numero de pessoas existentes no registo
    int getNumPessoas() const;

    //obter o numero de pessoas que contenham uma determinada string no nome
    int getNumPessoas(const string &nome) const;

    //Permite apagar todas as pessoas cujo BI está entre dois valores especificados
    void delPessoas(int bi1, int bi2);

    //Apaga todas as pessoas
    void delAllPessoas();

    //obter um ponteiro para a pessoa com o BI dado
    Pessoa* getPessoa(int bi);

private:
    string pais;
    //numero de pessoas inscritas
    int numPessoas = 0;
    vector<Pessoa> pessoas;
    set<Pessoa> pessoasSet;
    unordered_map<int, Pessoa> biToPessoa;
    //cria um array map com as pessoas
    map<int, Pessoa> biToPessoa2;

};


#endif //F6_EX2_REGISTOCIVIL_H
