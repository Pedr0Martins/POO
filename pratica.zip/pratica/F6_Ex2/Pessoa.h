#ifndef F6_EX2_PESSOA_H
#define F6_EX2_PESSOA_H
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <fstream>
#include <unordered_map>
#include <set>
#include <map>
using namespace std;


class Pessoa {
public:
    Pessoa(string nome, int bi, int nif);
    string getNome() const;
    int getBI() const;
    int getNIF() const;
    void setNome(string nome);
    string descricao() const;
// vai precisar de ser acrescentado por causa de RegCiv
// Pessoa();
    bool operator<(const Pessoa& other) const {
        return bi < other.bi;
    }

    bool operator==(const Pessoa& other) const {
        return bi == other.bi;
    }
private:
    string nome;
    int bi, nif;
};


#endif //F6_EX2_PESSOA_H
