#ifndef F7_EX3_PESSOA_H
#define F7_EX3_PESSOA_H

#include <string>
#include <iostream>
#include <sstream>
using namespace std;

class Pessoa {
public:
    Pessoa(string nome, int bi, int nif);
    string getNome() const;
    int getBI() const;
    int getNIF() const;
    void setNome(string nome);
    string descricao() const;
private:
    string nome;
    int bi, nif;
};

#endif //F7_EX3_PESSOA_H