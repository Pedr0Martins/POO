#include "Automovel.h"

Automovel::Automovel(const string& matricula, const string& marca, const string& modelo, int id) : matricula(matricula), marca(marca),
modelo(modelo), id(contadorCarrosConstruidos+1){
    contadorCarrosConstruidos++;
}

string Automovel::getMatricula() const {
    return matricula;
}

string Automovel::getMarca() const {
    return marca;
}

string Automovel::getModelo() const {
    return modelo;
}

int Automovel::getId() const {
    return id;
}

Automovel &Automovel::operator=(const Automovel &other) {
    if(this != &other){
        marca = other.marca;
        modelo = other.modelo;
    }
    return *this;
}

int Automovel::getContadorCarrosConstruidos() {
    return contadorCarrosConstruidos;
}

string Automovel::toString() const {
    stringstream ss;
    ss << "ID: " << id << endl;
    ss << "Matricula: " << matricula << endl;
    ss << "Marca: " << marca << endl;
    ss << "Modelo: " << modelo << endl;
    return ss.str();
}
