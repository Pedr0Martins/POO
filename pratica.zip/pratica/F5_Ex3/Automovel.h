#ifndef F5_EX3_AUTOMOVEL_H
#define F5_EX3_AUTOMOVEL_H
#include <iostream>
#include <sstream>
using namespace std;


class Automovel {
public:
    Automovel(const string& matricula, const string& marca, const string& modelo, int id=0);
    Automovel(const string& matricula);

    string getMatricula() const;
    string getMarca() const;
    string getModelo() const;
    int getId() const;

    Automovel& operator=(const Automovel& other);
    Automovel(const Automovel& other);

    static int getContadorCarrosConstruidos();

    string toString() const;

private:
    string matricula;
    string marca;
    string modelo;
    static int contadorCarrosConstruidos;
    int id;
};


#endif //F5_EX3_AUTOMOVEL_H
