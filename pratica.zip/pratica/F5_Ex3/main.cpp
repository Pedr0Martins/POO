#include "Automovel.h"

int Automovel::contadorCarrosConstruidos = 0;

int main() {
    Automovel automovel1("ABC-123", "Toyota", "Corolla");
    Automovel automovel2("XYZ-789", "Honda", "Civic");

    // Atribuição com matrícula intocada
    automovel1 = automovel2;

    cout << automovel1.toString() << endl;
    cout << automovel2.toString() << endl;

    cout << "Total de carros construidos: " << Automovel::getContadorCarrosConstruidos() << endl;

    return 0;
}
