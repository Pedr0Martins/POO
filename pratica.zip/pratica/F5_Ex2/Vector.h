#ifndef F5_EX2_VECTOR_H
#define F5_EX2_VECTOR_H

#include <ostream>
#include "Ponto.h"

class Vector {
public:
    Vector(float x, float y);
    Vector(double value);
    Vector() = default;

    double getX() const;
    double getY() const;

    void setX(double newX);
    void setY(double newY);

    string ObtemCoordenadas() const;

    double CalculateDistance(const Ponto& ponto) const;

    Vector operator+(const Vector& other) const;

    // Sobrecarga do operador de subtração (-) para a classe Vetor
    Vector operator-(const Vector& other) const;

    // Sobrecarga do operador de adição composta (+=) para a classe Vetor
    Vector& operator+=(const Vector& other);

    // Sobrecarga do operador de adição com um valor double
    Vector operator+(double value) const;

    // Sobrecarga do operador de subtração com um valor double
    Vector operator-(double value) const;

    // Sobrecarga do operador de igualdade (==) para a classe Vetor
    bool operator==(const Vector& other) const;

    // Sobrecarga do operador de desigualdade (!=) para a classe Vetor
    bool operator!=(const Vector& other) const;

    friend ostream &operator<<(ostream &os, const Vector &vector);

    friend istream &operator>>(istream &is, Vector &vector);



private:
    double x;
    double y;
};

#endif //F5_EX2_VECTOR_H
