#include "Vector.h"

Vector::Vector(float x, float y) : x(x), y(y){

}

double Vector::getX() const {
    return x;
}

double Vector::getY() const {
    return y;
}

void Vector::setX(double newX) {
    this->x = newX;
}

void Vector::setY(double newY) {
    this->y = newY;
}

string Vector::ObtemCoordenadas() const {
    ostringstream oss;
    oss << "x: " << x << " y: " << y;
    return oss.str();
}

double Vector::CalculateDistance(const Ponto &ponto) const {
    float deltaX = ponto.getX() - x;
    float deltaY = ponto.getY() - y;
    return sqrt(deltaX * deltaX + deltaY * deltaY);
}

Vector::Vector(double value):x(value), y(value) {

}

Vector Vector::operator+(const Vector &other) const {
    return Vector(x + other.x, y + other.y);
}

Vector Vector::operator-(const Vector &other) const {
    return Vector(x - other.x, y - other.y);
}

Vector &Vector::operator+=(const Vector &other) {
    x += other.x;
    y += other.y;
    return *this;
}

Vector Vector::operator+(double value) const {
    return Vector(x + value, y + value);
}

Vector Vector::operator-(double value) const {
    return Vector(x - value, y - value);
}

bool Vector::operator==(const Vector &other) const {
    return (x == other.x && y == other.y);
}

bool Vector::operator!=(const Vector &other) const {
    return !(*this == other);
}

ostream &operator<<(ostream &os, const Vector &vector) {
    os << "(" << vector.x << "," << vector.y << ")";
    return os;
}

istream &operator>>(istream &is, Vector &vector) {
    is >> vector.x >> vector.y;
    return is;
}

