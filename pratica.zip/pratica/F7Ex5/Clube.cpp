#include "Clube.h"


Clube::Clube(string nomeAtividade): nomeAtividade(nomeAtividade), capacidade(10), tamanho(0), socios(new Pessoa*[10]) {}

Clube::~Clube() {
    int i;
    // Destrutor para libertar a memória alocada para os socios
    for (i = 0; i < tamanho; i++) {
        delete socios[i];
    }
}

void Clube::adicionarSocio(Pessoa *socio) {
    int i;
    //verifica se o socio já existe no Clube
    for (i = 0; i < tamanho; i++) {
        if (socios[i]->getBI() == socio->getBI()) {
            cout << "Socio ja existente" << endl;
            return;
        }
    }
    //adiciona o socio ao vetor de ponteiros para Pessoa
    socios[tamanho++] = socio;
}

void Clube::removerSocio(int bi) {
    int i;
    //verifica se o socio existe no Clube
    for (i = 0; i < tamanho; i++) {
        if (socios[i]->getBI() == bi) {
            //liberta a memória alocada para o socio
            delete socios[i];
            //desloca os socios seguintes para a esquerda
            for (i++; i < tamanho; i++) {
                socios[i - 1] = socios[i];
            }
            tamanho--;
            cout << "Socio removido com sucesso" << endl;
            return;
        }
    }
    cout << "Socio inexistente" << endl;
}

string Clube::listarSocios() const {
    ostringstream oss;
    int i;
    for (i = 0; i < tamanho; i++) {
        oss << socios[i]->descricao() << endl;
    }
    return oss.str();
}
