#ifndef F7_EX4_CLUBE_H
#define F7_EX4_CLUBE_H

#include "RegistoCivil.h"

class Clube {
public:
    Clube(string nomeAtividade);
    ~Clube();  // Destrutor para liberar a memória alocada para os sócios

    void adicionarSocio(Pessoa* socio);
    void removerSocio(int bi);
    string listarSocios() const;

private:
    string nomeAtividade;
    Pessoa** socios;
    int capacidade;
    int tamanho;
};


#endif //F7_EX4_CLUBE_H
