#ifndef F7_EX4_REGISTOCIVIL_H
#define F7_EX4_REGISTOCIVIL_H

#include "Pessoa.h"

class RegistoCivil {
public:
    RegistoCivil(string nomePais);
    string getNomePais() const;
    bool adicionarPessoa(const Pessoa &p);
    ~RegistoCivil();
    string getNomePorBI(int bi) const;
    string listarPessoas() const;
    void atualizarNomePorBI(int bi, string novoNome);
    int getNumeroDePessoas() const;
    Pessoa* getPessoaPorBI(int bi);
    void removerPessoaPorBI(int bi);

private:
    string nomePais;
    vector<Pessoa *> pessoas;
};

#endif //F7_EX4_REGISTOCIVIL_H
