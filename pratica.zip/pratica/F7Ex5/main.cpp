#include "Clube.h"

int main() {
    RegistoCivil rc("Portugal");
    rc.adicionarPessoa(Pessoa("Maria", 12345678, 123456789));

    Clube c("Futebol");
    c.adicionarSocio(rc.getPessoaPorBI(12345678));

    rc.removerPessoaPorBI(12345678);

    cout << c.listarSocios() << endl;
    return 0;
}
