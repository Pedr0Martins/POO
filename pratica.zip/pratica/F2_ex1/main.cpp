#include <iostream>
#include <string>

using namespace std;

namespace DataStore {
    bool dadosSaoValidos(const string& str) {
        return (str.length() >= 5 && str.length() <= 10);
    }
}

namespace UserInterface {
    bool dadosSaoValidos(const string& str) {
        return (!str.empty() && isupper(str[0]));
    }
}

int main() {
    string input1 = "ABCDE";
    string input2 = "abcde";

    // chamar função dadosSaoValidos da área DataStore
    if (DataStore::dadosSaoValidos(input1)) {
        cout << "Dados validos para DataStore." << endl;
    } else {
        cout << "Dados invalidos para DataStore." << endl;
    }

    // chamar a função dadosSaoValidos da área UserInterface
    if (UserInterface::dadosSaoValidos(input2)) {
        cout << "Dados validos para UserInterface." << endl;
    } else {
        cout << "Dados invalidos para UserInterface." << endl;
    }

    return 0;
}
